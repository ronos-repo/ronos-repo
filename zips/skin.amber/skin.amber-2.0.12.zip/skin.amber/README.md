skin.amber
==========

Amber skin for Kodi/Helix
